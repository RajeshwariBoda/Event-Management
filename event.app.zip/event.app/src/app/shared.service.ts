import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders}from'@angular/common/http';
import{ Observable,throwError}from 'rxjs';

export class MemberList {

  fullname?: string;
  mobile?: number;
  type?: string;
  city?: string;
  date?: number;
}

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  url='http://localhost:3000';

  constructor(private _http:HttpClient) { }

  httpHeader ={
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  EventData(data:any):Observable<MemberList> {
    console.log("");
    return this._http.post<MemberList>(this.url + '/dashboard',JSON.stringify(data),this.httpHeader)
  }
  getTask():Observable<MemberList[]>{
    return this._http.get<MemberList[]>(this.url + '/dashboard', this.httpHeader);
   }
}
