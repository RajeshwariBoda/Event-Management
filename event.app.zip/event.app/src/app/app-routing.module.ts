import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ImageComponent } from './image/image.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ServesComponent } from './serves/serves.component';
import { ContactComponent } from './contact/contact.component';
import { EventbookComponent } from './eventbook/eventbook.component';
import { BookingformComponent } from './bookingform/bookingform.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AdminComponent } from './admin/admin.component';
import { AdminSignUpComponent } from './admin-sign-up/admin-sign-up.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PopularComponent } from './popular/popular.component';




const routes: Routes = [
 {path:'Images', component : ImageComponent },
 {path:'Login', component : LoginComponent },
 {path:'Home', component : HomeComponent },
 {path :'Serves',component : ServesComponent },
 {path :'Contact',component: ContactComponent},
 {path : 'Event', component : EventbookComponent},
 {path : 'Book', component : BookingformComponent},
 {path : 'sign-up', component : SignUpComponent},
 {path : 'admin', component:AdminComponent},
 {path : 'admin-sign-up', component: AdminSignUpComponent},
 {path : 'dashboard', component: DashboardComponent},
 {path : 'Popular',component:PopularComponent},

{path: '**', component : HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[ImageComponent,LoginComponent,HomeComponent]