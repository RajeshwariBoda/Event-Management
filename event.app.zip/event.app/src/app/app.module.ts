import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ServesComponent } from './serves/serves.component';
import { ContactComponent } from './contact/contact.component';
import { EventbookComponent } from './eventbook/eventbook.component';
import { BookingformComponent } from './bookingform/bookingform.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { LoginComponent } from './login/login.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AdminComponent } from './admin/admin.component';
import { AdminSignUpComponent } from './admin-sign-up/admin-sign-up.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PopularComponent } from './popular/popular.component';






@NgModule({
  declarations: [
    AppComponent,
   
    ServesComponent,
    ContactComponent,
    EventbookComponent,
    BookingformComponent,
    SignUpComponent,
    LoginComponent,
    AdminComponent,
    AdminSignUpComponent,
    DashboardComponent,
    PopularComponent,
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
